package com.csci448.vgirkins.criminalintent;

import android.support.v4.app.Fragment;

/**
 * Created by Tori on 2/13/2018.
 */

public class CrimeListActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() {
        return new CrimeListFragment();
    }
}
