/*
https://stackoverflow.com/questions/2506876/how-to-change-position-of-toast-in-android#2507069
https://www.android-examples.com/change-toast-message-background-color-in-android/
https://stackoverflow.com/questions/31162236/setbackgroundresource-in-android-studio-expects-drawable-not-int#31162324
https://stackoverflow.com/questions/3275333/how-to-use-a-xml-shape-drawable#4437303
 */
package com.csci448.vgirkins.geoquiz;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    private Button trueButton;
    private Button falseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        trueButton = findViewById(R.id.true_button);
        trueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View view ) {
                Toast toast = Toast.makeText(QuizActivity.this, R.string.right_answer_toast, Toast.LENGTH_SHORT );
                toast.setGravity(Gravity.TOP, 0, 0);
                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.background_toast);
                toast.show();

            }
        });

        falseButton = findViewById(R.id.false_button);
        falseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View view ) {
                Toast toast = Toast.makeText(QuizActivity.this, R.string.wrong_answer_toast, Toast.LENGTH_SHORT );
                toast.setGravity(Gravity.TOP, 0, 0);
                View toastView = toast.getView();
                toastView.setBackgroundResource(R.drawable.background_toast);
                toast.show();
            }
        });
    }

}
